#!/usr/bin/env python3
"""Generate datapackage.json and .zenodo.json for the public release.

Both files are derived from the tables themselves, so a change to the data
propagates to the metadata instead of leaving a stale hand-typed count.

    python build_metadata.py public/ghd_relational_database
"""
from pathlib import Path
import hashlib
import json
import sys

import pandas as pd

TITLE = ("A relational database of actors, claims, concepts and diplomatic actions "
         "in the global health diplomacy literature (1945-2026)")

# Frictionless type inference from pandas dtype, kept deliberately coarse.
def ftype(s):
    if pd.api.types.is_integer_dtype(s):  return "integer"
    if pd.api.types.is_float_dtype(s):    return "number"
    if pd.api.types.is_bool_dtype(s):     return "boolean"
    return "string"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def build(root):
    root = Path(root)
    manifest = pd.read_csv(root / "database_table_manifest.csv")
    codebook = pd.read_csv(root / "reference/product14_research_codebook.csv")
    redaction = pd.read_csv(root / "REDACTION_LOG.csv")
    docs = pd.read_csv(root / "tables/documents.csv", low_memory=False)

    cb_by = {}
    for _, r in codebook.iterrows():
        cb_by.setdefault(r["table"], {})[r["variable"]] = r

    # Row total covers the 13 data tables only. Reference files, the manifest and the
    # redaction logs are shipped as resources but are documentation, not observations.
    data_rows = int(manifest.n_rows.sum())

    resources = []
    for path in sorted(root.rglob("*.csv")):
        rel = path.relative_to(root).as_posix()
        df = pd.read_csv(path, low_memory=False)
        mrow = manifest[manifest.table == Path(rel).name]
        fields = []
        for c in df.columns:
            f = {"name": c, "type": ftype(df[c]),
                 "n_nonmissing": int(df[c].notna().sum())}
            cb = cb_by.get(Path(rel).name, {}).get(c)
            if cb is not None and pd.notna(cb.get("allowed_values_or_range")):
                v = str(cb["allowed_values_or_range"])
                f["allowed_values_or_range"] = v if len(v) <= 300 else v[:300] + " …"
            if c.endswith("_sha256_16"):
                f["description"] = ("First 16 hex characters of the SHA-256 of the withheld passage after "
                                    "whitespace collapse, strip and casefold. Recompute from your own copy "
                                    "of the source to confirm you located the passage we coded.")
            if c.endswith("_wordcount"):
                f["description"] = "Word count of the withheld passage."
            fields.append(f)
        res = {"name": rel.replace("/", "__").replace(".csv", ""), "path": rel,
               "profile": "tabular-data-resource", "format": "csv", "encoding": "utf-8",
               "mediatype": "text/csv", "bytes": path.stat().st_size,
               "hash": "sha256:" + sha256(path),
               "rows": len(df), "schema": {"fields": fields}}
        if len(mrow):
            m = mrow.iloc[0]
            res["description"] = str(m["purpose"])
            res["schema"]["primaryKey"] = [k.strip() for k in str(m["primary_key"]).split("+")] \
                if "+" in str(m["primary_key"]) else str(m["primary_key"])
            if pd.notna(m["foreign_keys"]) and "->" in str(m["foreign_keys"]):
                res["x-foreign-keys-prose"] = str(m["foreign_keys"])
        resources.append(res)

    totals = json.loads((root / "REDACTION_TOTALS.json").read_text())
    withheld = totals["words_unique_deposit_level"]
    n_red_cols = int(redaction.action.eq("redacted").sum())

    datapackage = {
        "profile": "tabular-data-package",
        "name": "ghd-relational-database",
        "title": TITLE,
        "description": (
            f"{len(manifest)} linked tables, {data_rows:,} rows, {len(codebook)} documented variables, "
            "derived from a systematic review of the global health diplomacy literature. "
            "Verbatim source passages are withheld in this public release and represented by position, "
            "word count and a SHA-256 digest; see REDACTION_LOG.csv and README.md."
        ),
        "licenses": [{"name": "CC-BY-4.0",
                      "path": "https://creativecommons.org/licenses/by/4.0/",
                      "title": "Creative Commons Attribution 4.0 International"}],
        "created": pd.Timestamp.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "x-corpus": {
            "corpus_A_scholarly": int((docs.corpus_group == "A").sum()),
            "corpus_B_institutional": int((docs.corpus_group == "B").sum()),
            "corpus_C_think_tank": int((docs.corpus_group == "C").sum()),
            "note": "The three corpora were identified by separate searches and are never pooled.",
        },
        "x-redaction": {"columns_redacted": n_red_cols, "verbatim_words_withheld": withheld,
                        "log": "REDACTION_LOG.csv"},
        "resources": resources,
    }
    (root / "datapackage.json").write_text(json.dumps(datapackage, indent=1))

    zenodo = {
        "title": TITLE,
        "upload_type": "dataset",
        "description": (
            "<p>A relational database of the global health diplomacy (GHD) literature, built as the data "
            f"layer of a systematic review. {len(manifest)} linked tables, {data_rows:,} rows and "
            f"{len(codebook)} documented variables.</p>"
            "<p>The database is organised around a claim-level table in which each row is one attribution "
            "made about one actor in one document, coded separately for role, action, health issue, "
            "diplomatic arena, partner, power source and objective. Companion tables cover the "
            "bibliographic register for three corpora, retrieval and coding-tier assignment, extracted "
            "concept definitions with their unit of analysis, detected diplomatic actions and frames, "
            "sentence-level power-mechanism and causal claims, middle-power attributions, and "
            "finance-to-influence claims.</p>"
            "<p><strong>Negative findings are part of the deposit.</strong> The middle-power tables record "
            "countries checked and never labelled; the diplomatic-actions table records whether each coded "
            "action is called diplomacy by its own source or is diplomacy only by analytical inference.</p>"
            "<p><strong>Verbatim source passages are withheld.</strong> Individually each passage was capped "
            "below 25 words, but aggregated per source document the quotation would have amounted to "
            f"substantial republication of third-party text, including non-open-licence material. All "
            f"{n_red_cols} verbatim columns ({withheld:,} words) are replaced by the passage position, its "
            "word count and a SHA-256 digest, so a reader with legitimate access to a source can locate the "
            "passage and confirm cryptographically that it is the one coded here. REDACTION_LOG.csv records "
            "exactly what was removed from where.</p>"
            "<p>Limits that bind any reuse are stated in README.md: coding-tier skew, the coding method "
            "recorded per row, an unresolved one-document discrepancy in the full-text denominator, "
            "licence-gated databases that were never searched, and the fact that no full text was obtained "
            "for any non-English work.</p>"
        ),
        "access_right": "open",
        "license": "cc-by-4.0",
        "keywords": ["global health diplomacy", "health diplomacy", "systematic review",
                     "relational database", "content analysis", "global health governance",
                     "middle powers", "actor-network analysis", "science of science",
                     "research data", "PRISMA"],
        "language": "eng",
        "notes": ("Verbatim source passages are withheld and represented by locator, word count and "
                  "SHA-256 digest. The unredacted coding file can be shared with researchers for "
                  "verification of the coding; see README.md."),
    }
    (root / ".zenodo.json").write_text(json.dumps(zenodo, indent=1))

    print(f"datapackage.json: {len(resources)} resources, {data_rows:,} table rows, "
          f"{len(codebook)} codebook variables")
    print(f".zenodo.json: {len(zenodo['keywords'])} keywords, licence {zenodo['license']}")
    return datapackage, zenodo


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "public/ghd_relational_database")
