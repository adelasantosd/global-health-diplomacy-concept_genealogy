#!/usr/bin/env python3
"""Produce the public (redacted) release of the GHD relational database.

Verbatim source text is removed from every table that carries it and replaced by
three things per row: the position of the passage in the source, its word count,
and the SHA-256 of its normalised form. A reader holding the source document can
locate the passage and confirm byte-for-byte that they found the one we coded,
without this deposit redistributing copyrighted text.

    python redact.py extract/ghd_relational_database public/

Nothing else in the tables is altered. Codes, categories, our own analytical
inferences and all structural columns pass through unchanged.
"""
from pathlib import Path
import hashlib
import json
import re
import sys

import pandas as pd

# table -> {verbatim column: locator columns that survive it}
# A locator of None means the table carries no positional column for that text,
# which is recorded in the manifest rather than silently ignored.
VERBATIM = {
    "tables/actor_claims_long.csv": {
        "supporting_passage": ["passage_char_start", "passage_location"],
        "source_statement": ["passage_char_start", "passage_location"],
    },
    "tables/causal_claims.csv":            {"sentence": ["sent_id", "char_start"]},
    "tables/power_mechanisms.csv":         {"source_sentence": ["sent_id"]},
    "tables/funding_power_claims.csv":     {"supporting_passage": ["char_start", "passage_id"]},
    "tables/middle_power_attributions.csv":{"supporting_passage": ["supporting_passage_location"]},
}

# Columns that read as free text but are OUR analysis, not source text. These stay.
# Kept explicit so the decision is auditable rather than implied by a heuristic.
OUR_ANALYSIS = {
    "tables/funding_power_claims.csv": ["notes", "analytical_inference", "evidence_supporting_causal_claim"],
    "tables/middle_power_matrix.csv":  ["our_analytical_classification", "contradictory_interpretations",
                                        "criterion_behavioural_evidence", "criterion_positional_evidence",
                                        "criterion_identity_evidence", "criterion_niche_evidence",
                                        "criterion_recognition_evidence", "criterion_relational_evidence",
                                        "specific_actions", "claimed_outcomes"],
}

# Mixed columns: mostly our paraphrase, but some rows are literal source quotes,
# identified by a flag column in the same table. Only the flagged rows are redacted,
# because blanket-redacting would destroy paraphrase we are entitled to publish and
# blanket-keeping would republish quoted text. The flag values that mean "quoted"
# are matched case-insensitively on the listed prefixes.
CONDITIONAL_VERBATIM = {
    "tables/concepts_definitions.csv": {
        "definition_text_or_close_paraphrase": {
            "flag_column": "is_verbatim_quote",
            "quoted_prefixes": ("yes", "partial"),
            "locators": ["source_location", "source_doi_or_id"],
        }
    }
}


def norm(s):
    """Normalise for hashing: collapse whitespace, strip, casefold."""
    return re.sub(r"\s+", " ", str(s)).strip().casefold()


def digest(s):
    return hashlib.sha256(norm(s).encode("utf-8")).hexdigest()[:16]


# Bibliographic metadata is citation-essential and stays even when a coded passage
# was drawn from it (a title coded as a passage is still the title). Everything else
# that exactly duplicates a withheld passage is redacted by the residual sweep, so
# the deposit never withholds a string in one column and publishes it in another.
BIBLIOGRAPHIC = {"title", "authors", "author", "keywords", "venue", "publisher",
                 "author_affiliations", "attributing_authors", "ckey"}
RESIDUAL_MIN_WORDS = 8


def residual_sweep(out_root, withheld_texts, log):
    """Redact any non-bibliographic cell that exactly duplicates a withheld passage."""
    for path in sorted(Path(out_root).rglob("*.csv")):
        rel = path.relative_to(out_root).as_posix()
        if rel.startswith("REDACTION"):
            continue
        df = pd.read_csv(path, low_memory=False)
        touched = False
        for c in df.columns:
            if df[c].dtype != object or c in BIBLIOGRAPHIC or c.endswith(("_sha256_16", "_wordcount")):
                continue
            vals = df[c].dropna().astype(str)
            if not len(vals):
                continue
            hit = vals.map(norm).isin(withheld_texts)
            if not hit.any():
                continue
            idx = vals[hit].index
            words = df.loc[idx, c].astype(str).str.split().str.len()
            if c + "_sha256_16" not in df.columns:
                df[c + "_sha256_16"] = None
                df[c + "_wordcount"] = None
            df.loc[idx, c + "_sha256_16"] = df.loc[idx, c].map(digest).values
            df.loc[idx, c + "_wordcount"] = words.values
            df.loc[idx, c] = "[redacted: duplicates a withheld passage]"
            touched = True
            log.append(dict(table=rel, column=c, action="redacted (residual duplicate sweep)",
                            n_rows=int(len(idx)), unique_texts=int(df.loc[idx, c + "_sha256_16"].nunique()),
                            words_row_sum=int(words.sum()), unique_words_within_column=int(words.sum()),
                            max_words=int(words.max()), locators_retained="row identifiers",
                            locators_absent="none"))
        if touched:
            df.to_csv(path, index=False)


def redact(src_root, out_root):
    src_root, out_root = Path(src_root), Path(out_root)
    out_root.mkdir(parents=True, exist_ok=True)
    log = []

    for path in sorted(src_root.rglob("*.csv")):
        rel = path.relative_to(src_root).as_posix()
        dest = out_root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        df = pd.read_csv(path, low_memory=False)
        spec = VERBATIM.get(rel, {})

        for col, locators in spec.items():
            if col not in df.columns:
                log.append(dict(table=rel, column=col, action="ABSENT — spec stale", n_rows=0))
                continue
            present = df[col].notna()
            words = df.loc[present, col].astype(str).str.split().str.len()
            have_loc = [l for l in locators if l in df.columns]
            missing_loc = [l for l in locators if l not in df.columns]

            df[col + "_wordcount"] = None
            df.loc[present, col + "_wordcount"] = words.values
            df[col + "_sha256_16"] = None
            df.loc[present, col + "_sha256_16"] = df.loc[present, col].map(digest).values
            df[col] = "[redacted: see " + (", ".join(have_loc) if have_loc else "row identifiers") + "]"
            df.loc[~present, col] = None

            # Row-sum double-counts: the same passage recurs across claim rows, and
            # source_statement is a superset of supporting_passage in the same table.
            # Report both, and let the deposit-level figure use the deduplicated one.
            uniq = df.loc[present, [col + "_sha256_16", col + "_wordcount"]].drop_duplicates(col + "_sha256_16")
            log.append(dict(
                table=rel, column=col, action="redacted",
                n_rows=int(present.sum()),
                unique_texts=int(uniq[col + "_sha256_16"].nunique()),
                words_row_sum=int(words.sum()),
                # Deduplicated WITHIN this column only. These figures are NOT additive
                # across columns: in actor_claims_long, source_statement contains
                # supporting_passage for the same claim. The deposit-level total is the
                # substring-collapsed figure in REDACTION_TOTALS.json.
                unique_words_within_column=int(uniq[col + "_wordcount"].sum()),
                max_words=int(words.max()) if len(words) else 0,
                locators_retained="; ".join(have_loc) or "none",
                locators_absent="; ".join(missing_loc) or "none",
            ))

        # Row-conditional redaction for mixed paraphrase/quote columns.
        for col, cfg in CONDITIONAL_VERBATIM.get(rel, {}).items():
            if col not in df.columns or cfg["flag_column"] not in df.columns:
                log.append(dict(table=rel, column=col, action="ABSENT — conditional spec stale", n_rows=0))
                continue
            flag = df[cfg["flag_column"]].astype(str).str.strip().str.lower()
            quoted = flag.str.startswith(cfg["quoted_prefixes"]) & df[col].notna()
            have_loc = [l for l in cfg["locators"] if l in df.columns]
            words = df.loc[quoted, col].astype(str).str.split().str.len()

            df[col + "_wordcount"] = None
            df.loc[quoted, col + "_wordcount"] = words.values
            df[col + "_sha256_16"] = None
            df.loc[quoted, col + "_sha256_16"] = df.loc[quoted, col].map(digest).values
            df.loc[quoted, col] = "[redacted: verbatim quote, see " + \
                (", ".join(have_loc) if have_loc else "row identifiers") + "]"

            log.append(dict(
                table=rel, column=col, action="redacted (rows flagged verbatim only)",
                n_rows=int(quoted.sum()),
                unique_texts=int(df.loc[quoted, col + "_sha256_16"].nunique()),
                words_row_sum=int(words.sum()), unique_words_within_column=int(words.sum()),
                max_words=int(words.max()) if len(words) else 0,
                locators_retained="; ".join(have_loc) or "none",
                locators_absent="; ".join(l for l in cfg["locators"] if l not in df.columns) or "none",
                rows_left_as_paraphrase=int((df[col].notna() & ~quoted).sum()),
            ))

        df.to_csv(dest, index=False)

    # Collect every withheld string, then sweep the public build for duplicates of it.
    withheld = set()
    for rel, spec in VERBATIM.items():
        src = pd.read_csv(src_root / rel, low_memory=False)
        for col in spec:
            if col in src.columns:
                withheld |= set(src[col].dropna().astype(str).map(norm))
    for rel, spec in CONDITIONAL_VERBATIM.items():
        src = pd.read_csv(src_root / rel, low_memory=False)
        for col, cfg in spec.items():
            if col in src.columns and cfg["flag_column"] in src.columns:
                f = src[cfg["flag_column"]].astype(str).str.strip().str.lower()
                q = f.str.startswith(cfg["quoted_prefixes"]) & src[col].notna()
                withheld |= set(src.loc[q, col].astype(str).map(norm))
    withheld = {t for t in withheld if len(t.split()) >= RESIDUAL_MIN_WORDS}
    residual_sweep(out_root, withheld, log)

    logdf = pd.DataFrame(log)
    logdf.to_csv(out_root / "REDACTION_LOG.csv", index=False)

    # Deposit-level exposure: unique passages per source document, pooled across
    # every redacted column, which is the figure a rights reviewer needs.
    pooled = []
    for rel, spec in VERBATIM.items():
        src = pd.read_csv(src_root / rel, low_memory=False)
        doccol = "document_id" if "document_id" in src.columns else "source_document_id"
        for col in spec:
            if col not in src.columns:
                continue
            sub = src.loc[src[col].notna(), [doccol, col]].rename(columns={doccol: "document_id", col: "txt"})
            pooled.append(sub)
    # Conditionally redacted quotes count towards per-document exposure too. These
    # tables key on a DOI/identifier rather than document_id, so the identifier is
    # carried through under that name and the pooled frame stays comparable.
    for rel, spec in CONDITIONAL_VERBATIM.items():
        src = pd.read_csv(src_root / rel, low_memory=False)
        for col, cfg in spec.items():
            if col not in src.columns or cfg["flag_column"] not in src.columns:
                continue
            flag = src[cfg["flag_column"]].astype(str).str.strip().str.lower()
            quoted = flag.str.startswith(cfg["quoted_prefixes"]) & src[col].notna()
            doccol = "document_id" if "document_id" in src.columns else "source_doi_or_id"
            sub = src.loc[quoted, [doccol, col]].rename(columns={doccol: "document_id", col: "txt"})
            pooled.append(sub)
    allp = pd.concat(pooled, ignore_index=True).dropna(subset=["document_id", "txt"])
    allp["txt"] = allp.txt.map(norm)
    allp = allp.drop_duplicates(["document_id", "txt"])

    # Exact deduplication is not enough: source_statement contains supporting_passage
    # for the same claim, so summing both double-counts the overlap. Keep only
    # passages that are not substrings of a longer passage from the same document.
    keep = []
    for did, grp in allp.groupby("document_id"):
        maximal = []
        for t in sorted(grp.txt.unique(), key=len, reverse=True):
            if not any(t in m for m in maximal):
                maximal.append(t)
        keep.extend((did, t) for t in maximal)
    K = pd.DataFrame(keep, columns=["document_id", "txt"])
    K["w"] = K.txt.str.split().str.len()
    per_doc = K.groupby("document_id").agg(maximal_passages=("txt", "size"),
                                           unique_words=("w", "sum")).sort_values("unique_words", ascending=False)
    per_doc.to_csv(out_root / "REDACTION_EXPOSURE_BY_DOCUMENT.csv")

    # One authoritative totals file, so no downstream consumer has to decide which
    # column of REDACTION_LOG.csv to sum (the per-column figures are not additive).
    totals = {
        "cells_redacted": int(logdf.n_rows.sum()),
        "columns_redacted": int(logdf.action.str.startswith("redacted").sum()),
        "words_row_sum": int(logdf.words_row_sum.sum()),
        "words_unique_within_column_sum": int(logdf.unique_words_within_column.sum()),
        "words_unique_deposit_level": int(per_doc.unique_words.sum()),
        "source_documents_affected": int(len(per_doc)),
        "max_unique_words_from_one_document": int(per_doc.unique_words.max()),
        "documents_over_500_unique_words": int((per_doc.unique_words > 500).sum()),
        "note": (
            "words_unique_deposit_level is THE figure to quote. It pools every redacted "
            "column, deduplicates exact repeats, and drops any passage that is a substring "
            "of a longer passage from the same source document. words_row_sum counts the "
            "same passage once per row it appears in. words_unique_within_column_sum "
            "deduplicates inside each column but is NOT additive across columns, because "
            "actor_claims_long.source_statement contains supporting_passage for the same "
            "claim; summing the per-column figures therefore double-counts that overlap."
        ),
    }
    (out_root / "REDACTION_TOTALS.json").write_text(json.dumps(totals, indent=1))
    return logdf, per_doc


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "extract/ghd_relational_database"
    out = sys.argv[2] if len(sys.argv) > 2 else "public/ghd_relational_database"
    lg, per_doc = redact(src, out)
    print(lg.to_string(index=False))
    print(f"\nredacted {lg.action.eq('redacted').sum()} columns, "
          f"{int(lg.unique_words_within_column.sum()):,} within-column unique words "
          f"(row-sum {int(lg.words_row_sum.sum()):,}; NOT additive across columns)")
    print(f"per-document exposure: {len(per_doc)} documents, "
          f"{int(per_doc.unique_words.sum()):,} unique words pooled across columns, "
          f"max {int(per_doc.unique_words.max()):,} from one document")
