#!/usr/bin/env python3
"""Write README.md for the public release, with every figure derived from the tables.

    python build_readme.py public/ghd_relational_database
"""
from pathlib import Path
import sys

import json
import re
import sys

import pandas as pd


SRC_HINT = Path("extract/ghd_relational_database")


def build(root):
    root = Path(root)
    man = pd.read_csv(root / "database_table_manifest.csv")
    cb = pd.read_csv(root / "reference/product14_research_codebook.csv")
    red = pd.read_csv(root / "REDACTION_LOG.csv")
    tot = json.loads((root / "REDACTION_TOTALS.json").read_text())
    exp = pd.read_csv(root / "REDACTION_EXPOSURE_BY_DOCUMENT.csv")
    rel = pd.read_csv(root / "reference/stage3_reliability_audit.csv")
    docs = pd.read_csv(root / "tables/documents.csv", low_memory=False)
    fi = pd.read_csv(root / "tables/fulltext_inventory.csv", low_memory=False)
    ac = pd.read_csv(root / "tables/actor_claims_long.csv", low_memory=False)
    da = pd.read_csv(root / "tables/diplomatic_actions.csv", low_memory=False)
    mm = pd.read_csv(root / "tables/middle_power_matrix.csv", low_memory=False)
    cd = pd.read_csv(root / "tables/concepts_definitions.csv", low_memory=False)

    A, B, C = [int((docs.corpus_group == g).sum()) for g in "ABC"]
    tier = fi.coding_tier.value_counts()
    method = ac.coding_method.value_counts()
    expl = int(da.explicitly_called_diplomacy.astype(str).str.lower().eq("true").sum())
    infer = int(da.analytical_inference_only.astype(str).str.lower().eq("true").sum())
    withheld_rows = tot["cells_redacted"]
    r = {row["audit"]: row for _, row in rel.iterrows()}

    # countries checked and never labelled: the negative finding in the matrix
    lab = mm.classification_by_the_literature.astype(str)
    never = int(lab.str.contains("never|not labelled|no source", case=False, na=False).sum())

    # Assertion count is read from the verifier itself rather than typed in.
    import subprocess
    vp = root / "scripts/verify_deposit.py"
    N_CHECKS = "a suite of"
    if vp.exists():
        proc = subprocess.run([sys.executable, str(vp), str(SRC_HINT), str(root)],
                              capture_output=True, text=True)
        m = re.search(r"(\d+) checks run", proc.stdout)
        if m:
            N_CHECKS = m.group(1)

    table_rows = "\n".join(
        f"| `{t['table']}` | {t['n_rows']:,} | {t['n_columns']} | {t['grain']} |"
        for _, t in man.iterrows())

    red_rows = "\n".join(
        f"| `{x['table'].split('/')[-1]}` | `{x['column']}` | {int(x['n_rows']):,} | "
        f"{int(x['unique_words_within_column']):,} | {int(x['max_words'])} | {x['locators_retained']} |"
        for _, x in red.sort_values("unique_words_within_column", ascending=False).iterrows())

    doc = f"""# A relational database of the global health diplomacy literature

**{len(man)} linked tables · {int(man.n_rows.sum()):,} rows · {len(cb)} documented variables**

This is the data layer of a systematic review of how global health diplomacy (GHD) is
written about: who is said to act, what they are said to do, which concepts are used to
describe it, and what evidence each claim rests on.

It is not a bibliography with codes attached. The central table records **one attribution
about one actor in one document per row**, with role, action, health issue, diplomatic
arena, partner, power source, objective and outcome coded as separate fields, so a user
can ask which actors are credited with which mechanisms and on what evidentiary basis,
rather than only counting publications.

## Contents

| Table | Rows | Columns | One row is |
|---|---:|---:|---|
{table_rows}

Alongside the tables, `reference/` holds the codebook ({len(cb)} variables with allowed
values and missingness), the entity-resolution log, the screening decisions, the search
log, the referential-integrity report and the reliability audit. `datapackage.json` is a
Frictionless tabular-data-package descriptor with a SHA-256 for every file.

`scripts/` contains the code that produced this release from the internal working copy:
`redact.py` (withholds verbatim source text), `build_metadata.py`, `build_readme.py` (this
file) and `verify_deposit.py`. The last one runs {N_CHECKS} assertions and exits non-zero if
any figure in this README or in `datapackage.json` disagrees with the tables, if a withheld
passage reappears anywhere in a non-bibliographic column, or if a hash fails to reproduce
its source passage. Run it before trusting a modified copy:

```bash
python scripts/verify_deposit.py <internal-working-copy> .
```

## Three corpora, never pooled

Corpus A is scholarly literature ({A:,} records). Corpus B is institutional and policy
documents ({B} records, WHO IRIS and the UN Digital Library). Corpus C is think-tank
output ({C} records). B and C were found through separate repository and web searches, not
through the bibliographic-index flow that produced A, so **they share no sampling frame
and must not be added together**. Every proportion in the review uses a single corpus as
its denominator.

## Verbatim source text is withheld

Each coded passage was individually capped below 25 words. Aggregated per source document,
however, the quotation amounted to substantial republication of third-party text: across
{tot['source_documents_affected']} documents the coded passages total
{tot['words_unique_deposit_level']:,} unique words, with up to
{tot['max_unique_words_from_one_document']:,} words from a single article and
{tot['documents_over_500_unique_words']} documents above 500 words. A large share of those
sources carry non-open licences.

Publishing that under CC BY would mean granting rights over text that is not ours to
license. So in this release **{withheld_rows:,} passage cells across
{tot['columns_redacted']} columns are replaced** by three fields:

- the position of the passage in the source (character offset, sentence id, or a location
  label such as `abstract` or `body @40% of text`),
- its word count,
- the first 16 hex characters of the SHA-256 of the passage after whitespace collapse,
  strip and casefold.

A reader with legitimate access to a source can go to the recorded position, take the
passage, hash it the same way and confirm byte-for-byte that they found the passage we
coded. Verification survives; redistribution does not.

| Table | Column | Cells | Unique words (within column) | Longest | Locators retained |
|---|---|---:|---:|---:|---|
{red_rows}

**Do not sum that last column.** Each figure is deduplicated within its own column, but the
columns overlap: in `actor_claims_long.csv`, `source_statement` contains
`supporting_passage` for the same claim. Adding them gives
{tot['words_unique_within_column_sum']:,} words and double-counts that containment; counting
every row separately gives {tot['words_row_sum']:,} and double-counts passages that recur
across claim rows. The figure to quote is **{tot['words_unique_deposit_level']:,} unique
words**, computed by pooling every redacted column, deduplicating exact repeats, and
dropping any passage that is a substring of a longer passage from the same source document.
All four totals, and which one to use, are in `REDACTION_TOTALS.json`.

`REDACTION_LOG.csv` records this per column, including which cells were left as paraphrase.
`REDACTION_EXPOSURE_BY_DOCUMENT.csv` gives the per-source-document exposure that motivated
the decision. Three points of detail, because they are the kind of thing that is easy to get
wrong and hard to spot:

1. In `concepts_definitions.csv` only the {int(cd.is_verbatim_quote.astype(str).str.lower().str.startswith(('yes','partial')).sum())}
   rows flagged `is_verbatim_quote` are redacted. The remaining
   {int(cd.definition_text_or_close_paraphrase.notna().sum() - cd.is_verbatim_quote.astype(str).str.lower().str.startswith(('yes','partial')).sum())}
   rows are our own paraphrase of a definition and are published in full.
2. A residual sweep redacts any other cell that exactly duplicates a withheld passage, so
   the deposit never withholds a string in one column while publishing it in another.
3. Bibliographic metadata (title, authors, keywords, venue) stays even where a passage was
   coded from the title, because a title is citation-essential and remains a title.

**The unredacted coding file can be shared with researchers for verification of the
coding.** Contact the author through the Zenodo record.

## Limits that bind reuse

**Coding tiers are uneven, and the skew is measured rather than assumed.** Of the {A:,}
Corpus A records, {int(tier.get('fulltext_deep', 0)):,} are full-text deep-coded
({tier.get('fulltext_deep', 0)/A*100:.1f}%), {int(tier.get('abstract_only', 0)):,} are
abstract-only and {int(tier.get('metadata_only', 0)):,} are metadata-only. The dominant
driver is document type, not author region. Sentence-level tables
(`power_mechanisms.csv`, `causal_claims.csv`) exist for deep-tier documents only.

**Coding method is recorded per row and is mostly deterministic.** In
`actor_claims_long.csv`, {int(method.get('rule_based_v1', 0)):,} rows carry
`rule_based_v1` and {int(method.get('llm:claude-sonnet-5', 0))} carry LLM-assisted coding.
Anyone treating the claim table as human-coded content analysis would be wrong; the
`coding_method` column exists so that assumption cannot be made silently.

**Reliability is reported, including where it is weak.** Sampled passages are 100%
verbatim-verified in the source text ({int(r['passage_verbatim']['n'])} sampled) and
mention strings resolve at {r['mention_string_integrity_strict']['value']}% strict
({r['mention_string_integrity_ws_normalized']['value']}% after whitespace normalisation).
Role intercoder agreement is {r['role_intercoder_agreement']['value']}% on
{int(r['role_intercoder_agreement']['n'])} sampled claims, which is moderate; role
assignments should be treated as indicative rather than settled.

**The field's own terminology is looser than it looks.** Of {len(da):,} coded diplomatic
actions, {expl:,} ({expl/len(da)*100:.1f}%) are explicitly called diplomacy by their own
source, and {infer:,} ({infer/len(da)*100:.1f}%) are diplomacy by analytical inference
only. That distinction is a column, not a footnote.

**Negative findings are in the data.** `middle_power_matrix.csv` covers {len(mm)} countries
and deliberately includes those checked against the literature and never labelled a middle
power. Absence of a label is evidence about the literature, not missing data.

**Databases that were never searched.** Web of Science, Scopus, JSTOR, ProQuest, PAIS
International, HeinOnline and Google Scholar were all licence-gated and unreachable from
the analysis environment. Recall of non-indexed, non-English and grey literature is
unquantified, and every coverage claim is bounded by that.

**No full text was obtained for any non-English work.** Characterisations of the Lusophone,
Hispanophone, Francophone, Germanophone and Sinophone literatures rest on titles,
abstracts, authors and venues.

**One unresolved discrepancy, left visible.** The full-text denominator is reported as 425
in one review output and 426 in another. The reconciliation was not completed. It is
recorded here rather than silently harmonised.

## Suggested uses

The claim table supports actor-level questions that publication counts cannot answer:
which actors are credited with which power mechanisms, how often a claim is supported by
source-explicit evidence versus analytical inference, and how the actor set changes across
health issues and diplomatic arenas. `concepts_definitions.csv` supports concept work,
since each definition carries its unit of analysis, which is what makes definitions
comparable at all.

Anyone recomputing published figures should start from `reference/product14_research_codebook.csv`
for the denominators and read the limits above first.

## Citation

Cite the Zenodo DOI of this record. Attribution must preserve the limits stated in this
README; they are what make the database usable rather than decorative.

## Licence

Data and documentation: Creative Commons Attribution 4.0 International (CC BY 4.0).
Bibliographic metadata for the underlying sources is factual reference information; the
sources themselves remain under their own publishers' terms and are not redistributed here.
"""
    (root / "README.md").write_text(doc)
    print(f"README.md written: {len(doc.split()):,} words")
    return doc


if __name__ == "__main__":
    build(sys.argv[1] if len(sys.argv) > 1 else "public/ghd_relational_database")
