#!/usr/bin/env python3
"""Fail if the public release is not safe to deposit or not internally consistent.

Run after redact.py, build_metadata.py and build_readme.py.

    python verify_deposit.py extract/ghd_relational_database public/ghd_relational_database
"""
from pathlib import Path
import hashlib
import json
import re
import sys

import pandas as pd

VERBATIM = {
    "tables/actor_claims_long.csv": ["supporting_passage", "source_statement"],
    "tables/causal_claims.csv": ["sentence"],
    "tables/power_mechanisms.csv": ["source_sentence"],
    "tables/funding_power_claims.csv": ["supporting_passage"],
    "tables/middle_power_attributions.csv": ["supporting_passage"],
}
BIBLIOGRAPHIC = {"title", "authors", "author", "keywords", "venue", "publisher",
                 "author_affiliations", "attributing_authors", "ckey"}
MIN_WORDS = 8

fails, checks = [], 0


def check(label, ok, detail=""):
    global checks
    checks += 1
    if not ok:
        fails.append(f"{label}{(' — ' + detail) if detail else ''}")


def norm(s):
    return re.sub(r"\s+", " ", str(s)).strip().casefold()


def main(src_root, pub_root):
    src, pub = Path(src_root), Path(pub_root)

    # ---- the set of strings this deposit promised to withhold ----
    withheld = set()
    for rel, cols in VERBATIM.items():
        d = pd.read_csv(src / rel, low_memory=False)
        for c in cols:
            if c in d.columns:
                withheld |= set(d[c].dropna().astype(str).map(norm))
    cds = pd.read_csv(src / "tables/concepts_definitions.csv", low_memory=False)
    flag = cds.is_verbatim_quote.astype(str).str.strip().str.lower()
    quoted_mask = flag.str.startswith(("yes", "partial")) & cds.definition_text_or_close_paraphrase.notna()
    withheld |= set(cds.loc[quoted_mask, "definition_text_or_close_paraphrase"].astype(str).map(norm))
    long_withheld = {t for t in withheld if len(t.split()) >= MIN_WORDS}

    # ---- 1. no withheld string survives in a non-bibliographic public column ----
    leaks = []
    for path in sorted(pub.rglob("*.csv")):
        if path.name.startswith("REDACTION"):
            continue
        df = pd.read_csv(path, low_memory=False)
        for c in df.columns:
            if df[c].dtype != object or c in BIBLIOGRAPHIC or c.endswith(("_sha256_16", "_wordcount")):
                continue
            hit = set(df[c].dropna().astype(str).map(norm)) & long_withheld
            if hit:
                leaks.append(f"{path.relative_to(pub)}::{c} ({len(hit)} cells)")
    check("withheld source text still present in the public build", not leaks, "; ".join(leaks[:4]))

    # ---- 2. every redacted column carries a locator, a wordcount and a hash ----
    for rel, cols in VERBATIM.items():
        s = pd.read_csv(src / rel, low_memory=False)
        p = pd.read_csv(pub / rel, low_memory=False)
        for c in cols:
            if c not in s.columns:
                continue
            m = s[c].notna()
            check(f"{rel}::{c} hash column missing", c + "_sha256_16" in p.columns)
            check(f"{rel}::{c} wordcount column missing", c + "_wordcount" in p.columns)
            if c + "_sha256_16" not in p.columns:
                continue
            check(f"{rel}::{c} hash absent on redacted rows",
                  int(p.loc[m, c + "_sha256_16"].notna().sum()) == int(m.sum()))
            rt = s.loc[m, c].map(lambda x: hashlib.sha256(norm(x).encode()).hexdigest()[:16])
            check(f"{rel}::{c} hash does not reproduce the source passage",
                  (rt.values == p.loc[m, c + "_sha256_16"].values).all())
            check(f"{rel}::{c} wordcount does not match the source passage",
                  (s.loc[m, c].astype(str).str.split().str.len().values ==
                   p.loc[m, c + "_wordcount"].values).all())
            check(f"{rel}::{c} public cells not replaced by a redaction marker",
                  p.loc[m, c].astype(str).str.startswith("[redacted").all())

    # ---- 3. conditional column: quotes gone, paraphrase intact ----
    cdp = pd.read_csv(pub / "tables/concepts_definitions.csv", low_memory=False)
    check("flagged verbatim definitions not redacted",
          cdp.loc[quoted_mask, "definition_text_or_close_paraphrase"].astype(str).str.startswith("[redacted").all())
    keep = ~quoted_mask & cds.definition_text_or_close_paraphrase.notna()
    check("paraphrase definitions were altered",
          (cds.loc[keep, "definition_text_or_close_paraphrase"].values ==
           cdp.loc[keep, "definition_text_or_close_paraphrase"].values).all())

    # ---- 4. structure survives redaction ----
    for path in sorted(src.rglob("*.csv")):
        rel = path.relative_to(src).as_posix()
        a = pd.read_csv(path, low_memory=False)
        b = pd.read_csv(pub / rel, low_memory=False)
        check(f"{rel} row count changed", len(a) == len(b), f"{len(a)} vs {len(b)}")
        lost = [c for c in a.columns if c not in b.columns]
        check(f"{rel} columns dropped", not lost, str(lost))

    # ---- 5. keys and referential integrity on the PUBLIC build ----
    pdocs = pd.read_csv(pub / "tables/documents.csv", low_memory=False)
    pacts = pd.read_csv(pub / "tables/actors.csv", low_memory=False)
    did, aid = set(pdocs.document_id), set(pacts.actor_id)
    for t, fk, ref in [("actor_claims_long", "document_id", did), ("actor_claims_long", "actor_id", aid),
                       ("actor_document_mentions", "document_id", did), ("actor_document_mentions", "actor_id", aid),
                       ("diplomatic_actions", "document_id", did), ("frames", "document_id", did),
                       ("power_mechanisms", "document_id", did), ("causal_claims", "document_id", did),
                       ("funding_power_claims", "document_id", did), ("fulltext_inventory", "document_id", did)]:
        d = pd.read_csv(pub / f"tables/{t}.csv", low_memory=False)
        orph = set(d[fk].dropna()) - ref
        check(f"{t}.{fk} has orphan keys", not orph, str(sorted(orph)[:3]))
    for t, pk in [("documents", ["document_id"]), ("actors", ["actor_id"]),
                  ("actor_claims_long", ["claim_id"]), ("concepts_definitions", ["definition_id"]),
                  ("middle_power_matrix", ["country"]), ("funding_power_claims", ["claim_id"]),
                  ("middle_power_attributions", ["attribution_id"]),
                  ("actor_document_mentions", ["document_id", "actor_id"]),
                  ("diplomatic_actions", ["document_id", "action_code"])]:
        d = pd.read_csv(pub / f"tables/{t}.csv", low_memory=False)
        check(f"{t} primary key not unique", not d.duplicated(pk).any())

    # ---- 6. metadata and README agree with the tables ----
    dp = json.loads((pub / "datapackage.json").read_text())
    man = pd.read_csv(pub / "database_table_manifest.csv")
    readme = (pub / "README.md").read_text()
    exp = pd.read_csv(pub / "REDACTION_EXPOSURE_BY_DOCUMENT.csv")
    red = pd.read_csv(pub / "REDACTION_LOG.csv")
    tot = json.loads((pub / "REDACTION_TOTALS.json").read_text())

    check("datapackage resource count wrong", len(dp["resources"]) == len(list(pub.rglob("*.csv"))))
    check("datapackage row totals disagree with the manifest",
          f"{int(man.n_rows.sum()):,}" in dp["description"])
    for res in dp["resources"]:
        f = pub / res["path"]
        check(f"{res['path']} sha256 in datapackage is stale",
              res["hash"] == "sha256:" + hashlib.sha256(f.read_bytes()).hexdigest())
        check(f"{res['path']} row count in datapackage is stale",
              res["rows"] == len(pd.read_csv(f, low_memory=False)))
    # Anchored to the headline line itself, not a bare substring search: "13" also
    # occurs elsewhere in the README, so `str(13) in readme` passes even when the
    # headline says 14. Parse the headline and compare the three numbers directly.
    n_vars = len(pd.read_csv(pub / "reference/product14_research_codebook.csv"))
    head = re.search(r"\*\*([\d,]+) linked tables · ([\d,]+) rows · ([\d,]+) documented variables\*\*", readme)
    check("README headline line missing or reformatted", head is not None)
    if head:
        got = [int(g.replace(",", "")) for g in head.groups()]
        want = [len(man), int(man.n_rows.sum()), n_vars]
        check("README headline figures are stale", got == want, f"{got} vs {want}")
    # The deposit-level total must be the substring-collapsed figure, and the README
    # must quote THAT one rather than either double-counting total.
    check("REDACTION_TOTALS deposit-level figure disagrees with the per-document file",
          tot["words_unique_deposit_level"] == int(exp.unique_words.sum()))
    check("REDACTION_TOTALS within-column sum disagrees with the log",
          tot["words_unique_within_column_sum"] == int(red.unique_words_within_column.sum()))
    check("deposit-level total is not strictly below the within-column sum "
          "(the cross-column overlap was not collapsed)",
          tot["words_unique_deposit_level"] < tot["words_unique_within_column_sum"] < tot["words_row_sum"])
    check("README does not quote the deposit-level figure as the one to use",
          f"**{tot['words_unique_deposit_level']:,} unique" in readme)
    check("README omits the do-not-sum caveat",
          "Do not sum that last column" in readme and
          f"{tot['words_unique_within_column_sum']:,} words and double-counts" in readme)
    check("REDACTION_LOG still carries a column named as if it were additive",
          "unique_words" not in [c for c in red.columns if c == "unique_words"])
    check("README does not state the licence", "CC BY 4.0" in readme)
    check("README does not disclose the unresolved denominator discrepancy",
          "425" in readme and "426" in readme)
    check("README does not disclose the unsearched databases",
          "Web of Science" in readme and "Scopus" in readme)
    z = json.loads((pub / ".zenodo.json").read_text())
    check("zenodo licence is not CC BY 4.0", z["license"] == "cc-by-4.0")
    check("zenodo record does not disclose the redaction", "withheld" in z["description"].lower())

    print(f"{checks} checks run, {len(fails)} failed")
    if fails:
        for f in fails:
            print("  FAIL:", f)
        sys.exit(1)
    print("public release is internally consistent and carries no withheld source text")


if __name__ == "__main__":
    a = sys.argv[1] if len(sys.argv) > 1 else "extract/ghd_relational_database"
    b = sys.argv[2] if len(sys.argv) > 2 else "public/ghd_relational_database"
    main(a, b)
